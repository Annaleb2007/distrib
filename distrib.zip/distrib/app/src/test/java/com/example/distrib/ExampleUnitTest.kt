import com.example.distrib.MainActivity
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun getLogNormalRandomValue_returnsPositiveValue() {
        // Given
        val mean = 0.0
        val variance = 1.0

        // When
        val result = MainActivity().getLogNormalRandomValue(mean, variance)

        // Then
        assert(result > 0.0)
    }

    @Test
    fun getLogNormalRandomValue_returnsDifferentValues() {
        // Given
        val mean = 0.0
        val variance = 1.0

        // When
        val result1 = MainActivity().getLogNormalRandomValue(mean, variance)
        val result2 = MainActivity().getLogNormalRandomValue(mean, variance)

        // Then
        assert(result1 != result2)
    }
}
