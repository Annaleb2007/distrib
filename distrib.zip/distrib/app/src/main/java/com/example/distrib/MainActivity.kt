package com.example.distrib

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.util.*
import java.util.concurrent.ThreadLocalRandom
import kotlin.math.exp
import kotlin.math.sqrt


class MainActivity : AppCompatActivity() {

    private lateinit var meanEditText: EditText
    private lateinit var varianceEditText: EditText
    private lateinit var getNumButton: Button
    private lateinit var resultTextView: TextView

    // Log-Normal Distribution
    private val random = Random()
    private var mean = 0.0
    private var variance = 1.0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        meanEditText = findViewById(R.id.mean_val)
        varianceEditText = findViewById(R.id.variance_value)
        getNumButton = findViewById(R.id.get_random_num)
        resultTextView = findViewById(R.id.random_number_result)

        getNumButton.setOnClickListener {
            if (meanEditText.text.isNotEmpty() && varianceEditText.text.isNotEmpty()) {
                mean = meanEditText.text.toString().toDouble()
                variance = varianceEditText.text.toString().toDouble()
                val num = getLogNormalRandomValue(mean, variance)
                resultTextView.text = num.toString()
            }
        }

    }

    fun getLogNormalRandomValue(mean: Double, variance: Double): Double {
        val standardNormalRandomValue = random.nextGaussian()
        return exp(mean + variance / 2.0) * exp(standardNormalRandomValue * sqrt(variance))
    }

}